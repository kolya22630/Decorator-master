#include "darkroast.h"

DarkRoast::DarkRoast()
{
    description = "Dark Roast Coffee";
}

double DarkRoast::cost() {
    return 0.99;
}
