#include "houseblend.h"

HouseBlend::HouseBlend()
{
    description = "House Blend Coffee";
}

HouseBlend::~HouseBlend()
{

}

double HouseBlend::cost() {
    return 0.89;
}
